Lab 000 – Artificial Zoo using SVG graphics 

my "artificial zoo" program is an L-system - see photo at this link, from this link
https://en.wikipedia.org/wiki/L-system


which, it appears to me, is a particular implementation of an Iterated Function System https://en.wikipedia.org/wiki/Iterated_function_system

I designed the program to be given to students as an outline and for them to code the drawing

I probably got the idea from one of Richard Dawkins’ books, The Blind Watchmaker or The Selfish Gene 
https://www.amazon.com/Richard-Dawkins/e/B000AQ3RBI

Also related, at least artistically, to [Alan] Turing patterns
https://en.wikipedia.org/wiki/Turing_pattern
